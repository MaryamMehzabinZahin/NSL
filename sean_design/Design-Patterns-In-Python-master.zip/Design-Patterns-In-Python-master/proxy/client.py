"The Proxy Example Use Case"

from lion import Lion

PROTEUS = Lion()
PROTEUS.tell_me_your_form()
PROTEUS.tell_me_the_future()
PROTEUS.tell_me_your_form()
PROTEUS.tell_me_the_future()
PROTEUS.tell_me_your_form()
PROTEUS.tell_me_the_future()
PROTEUS.tell_me_your_form()
PROTEUS.tell_me_the_future()
PROTEUS.tell_me_your_form()
PROTEUS.tell_me_the_future()
